// msword.h

#ifndef MSWORD_H
#define MSWORD_H

#define DICTIONARY_AMERICAN "C:\\Program Files\\Common Files\\Microsoft Shared\\Proof\\MSSP3ENA.LEX"

#include <string>
#include "olebase.h"

class MSWord : public OleBase
{
	public:
		MSWord();
		~MSWord();
		bool checkSpelling(string s, string dictionaryPath = "");
		bool checkSpellingAmerican(string s);
		bool close();
		bool openFile(string &fname, bool readonly = false);
		bool replaceAll(string &find, string &replace);
		bool saveTextFile(string &fname);
		bool saveUnicodeFile(string &fname);
		bool saveXmlFile(string &fname);
		bool saveFile(string &fname, int wdFormat = 0);
		int getMajorVersion();
	private:
		enum constants {
			wdFormatDOSText = 4,
			wdFormatUnicodeText = 7,
			wdFormatXML = 11,
			wdReplaceAll = 2,
			wdWholeStory = 6,
			msoEncodingUTF8 = 65001
		};
		IDispatch *pDoc, *pDocs, *pSelection, *pFind, *pReplacement;
		DISPID CheckSpellingID, QuitID;
		bool application();
		void quit();
};

#endif
