// msie.h

#ifndef MSIE_H
#define MSIE_H

#include <string>
#include "olebase.h"

class MSIE : public OleBase
{
	public:
		MSIE();
		~MSIE();
		bool menubar(bool b);
		bool navigate(string &url);
		bool resizable(bool b);
		bool statusbar(bool b);
		bool theatermode(bool b);
		bool toolbar(bool b);
		HWND ie_handle();
	private:
		DISPID HandleID, MenuBarID, QuitID, ResizableID, StatusBarID, TheaterModeID, ToolBarID;
		bool application();
		void quit();
};

#endif
