#ifndef MSXML_H
#define MSXML_H

#include <string>
#include "olebase.h"

class MSXML : public OleBase
{
	public:
                MSXML();
                ~MSXML();
                bool load(const string &fname, bool loadOnly = false);
		string getLastError();
	private:
		bool application();
		string lastError;
};

#endif
