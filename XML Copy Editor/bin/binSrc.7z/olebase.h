// olebase.h

#ifndef OLEBASE_H
#define OLEBASE_H

#include <windows.h>
#include <ole2.h>
#include <string>

using namespace std;

class OleBase
{
	public:
		OleBase();
		virtual ~OleBase() {};
		bool getQuitOnDestruct();
		bool getVerbose();
		bool is_success();
		bool visible(bool b);
		void setQuitOnDestruct(bool b);
		void setVerbose(bool b);
	protected:
		IDispatch *pApp;
		bool success, verbose;

		virtual bool application()=0;
		bool call(int autoType, VARIANT *pvResult, IDispatch *pDisp, LPOLESTR ptName, DISPID dispID, int cArgs...);
		bool fetchDISPID(LPOLESTR ptName, IDispatch *pDisp, DISPID *dispID);
		void error(const string &method, const string &argument);
		wchar_t *stringToWideString(char *s);
		char *wideStringToString(wchar_t *ws);
		VARIANT optional_variant;
	private:
		bool quit_on_destruct_;
};

#endif
