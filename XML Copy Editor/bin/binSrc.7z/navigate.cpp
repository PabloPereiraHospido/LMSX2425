#include <windows.h>
#include <string>
#include <stdexcept>
#include "olebase.h"
#include "msie.h"

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)
{
	if (__argc < 2)
	{
		MessageBox(
			NULL,
			"Usage: navigate <web address or file path>\r\n"
			"Return values:\r\n"
			"0\tSuccess\r\n"
			"1\tUnable to create an instance of Internet Explorer",
			"Navigate",
			MB_OK);
		return 2;
	}
	try
	{
		MSIE ie;
		ie.setQuitOnDestruct(false);
		ie.visible(true);
		string address = *(++__argv);
		ie.navigate(address);
	}
	catch (exception &e)
	{
		return 1;
	}
	return 0;
}
