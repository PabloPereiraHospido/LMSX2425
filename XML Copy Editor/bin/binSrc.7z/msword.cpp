// msword.cpp

#include <windows.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <ole2.h>
#include <stdexcept>
#include "msword.h"

MSWord::MSWord() : pDocs(NULL), pDoc(NULL)
{
	CoInitialize(NULL);
	if ((success = application()) == 0)
		throw runtime_error("MSWord::MSWord");
	fetchDISPID(L"Quit", pApp, &QuitID);
	fetchDISPID(L"CheckSpelling", pApp, &CheckSpellingID);
}

MSWord::~MSWord()
{
	if (getQuitOnDestruct())
		quit();
	CoUninitialize();
}

bool MSWord::application()
{
	CoInitialize(NULL);
	CLSID clsid;
	HRESULT hr = CLSIDFromProgID(L"Word.Application", &clsid);

	if (FAILED(hr))
	{
		error(string("CLSIDFromProgID"), string("Word.Application"));
		success = false;
		return false;
	}

	// fetch IDispatch
	hr = CoCreateInstance(clsid, NULL, CLSCTX_LOCAL_SERVER, IID_IDispatch, (void **)&pApp);
	if (FAILED(hr))
	{
		error(string("CoCreateInstance"), string("IDispatch"));
		success = false;
		return false;
	}
	
	return true;
}

bool MSWord::checkSpelling(string s, string dictionaryPath)
{
	if (!is_success())
		return false;

	wchar_t *ws;
	if ((ws = stringToWideString((char *)s.c_str())) == NULL)
		return false;

	VARIANT result;
	VariantInit(&result);
	VARIANT x;
	VariantInit(&x);
	x.vt = VT_BSTR;
	x.bstrVal = ws;

	if (dictionaryPath == "")
		call(DISPATCH_METHOD, &result, pApp, L"CheckSpelling", CheckSpellingID, 1, x);
	else
	{
		wchar_t *wpath;
		if ((wpath = stringToWideString((char *)dictionaryPath.c_str())) == NULL)
			return false;
		VARIANT dictionaryPathVariant;
		VariantInit(&dictionaryPathVariant);
		dictionaryPathVariant.vt = VT_BSTR;
		dictionaryPathVariant.bstrVal = wpath;

		call(DISPATCH_METHOD, &result, pApp, L"CheckSpelling", CheckSpellingID, 3, dictionaryPathVariant, optional_variant, x);
		delete[] wpath;
	}

	delete[] ws;

	return (!result.boolVal) ? false : true;
}

bool MSWord::checkSpellingAmerican(string s)
{
	return checkSpelling(s, DICTIONARY_AMERICAN);
}

bool MSWord::close()
{
	if (!is_success() || pDoc == NULL)
		return false;
	VARIANT x;
	x.vt = VT_BOOL;
	x.boolVal = false;
	call(DISPATCH_METHOD, NULL, pDoc, L"Close", NULL, 1, x);
	return true;
}

int MSWord::getMajorVersion()
{
	if (!is_success())
		return 0;
	VARIANT versionVariant;
	VariantInit(&versionVariant);

	if (!call(DISPATCH_PROPERTYGET, &versionVariant, pApp, L"Version", NULL, 0))
		return 0;

	wchar_t *versionWideString = versionVariant.bstrVal;

	char *cString;
	cString = wideStringToString(versionWideString);
	if (!cString)
		return 0;

	char *it;
	for (it = cString; *it; ++it)
	{
		if (!isdigit(*it))
		{
			*it = '\0';
			break;
		}
	}
	return atoi(cString);
}

bool MSWord::openFile(string &fname, bool readonly)
{
	if (!is_success() || fname == "")
		return false;

	// Fetch pDocs
	if (pDocs == NULL)
	{
		VARIANT result;
		VariantInit(&result);
		call(DISPATCH_PROPERTYGET, &result, pApp, L"Documents", NULL, 0);
		pDocs = result.pdispVal;
	}

	wchar_t *wfname;
	if ((wfname = stringToWideString((char *)fname.c_str())) == NULL)
		return false;

	// Call Documents.Open(); fetch pDoc
	{
		VARIANT result;
		VariantInit(&result);
		VARIANT x, y, z;
		
		// filename
		x.vt = VT_BSTR;
		x.bstrVal = wfname;
		
		// confirm conversion = false
		y.vt = VT_BOOL;
		y.boolVal = false;
		
		// read only?
		z.vt = VT_BOOL;
		z.boolVal = readonly;

		call(DISPATCH_METHOD, &result, pDocs, L"Open", NULL, 3, z, y, x);
		pDoc = result.pdispVal;
	}
	delete[] wfname;
	return true;
}

bool MSWord::replaceAll(string &find, string &replace)
{
	if (!is_success() || pDoc == NULL)
		return false;

	// fetch pSelection 
	VARIANT selection_result_variant;
	VariantInit(&selection_result_variant);
	call(DISPATCH_PROPERTYGET, &selection_result_variant, pApp, L"Selection", NULL, 0);
	pSelection = selection_result_variant.pdispVal;

	// expand selection to wdWholeStory
	VARIANT word_story_variant;
	VariantInit(&word_story_variant);
	word_story_variant.vt = VT_I4;
	word_story_variant.lVal = wdWholeStory;

	call(DISPATCH_METHOD, NULL, pSelection, L"Expand", NULL, 1, word_story_variant);

	// fetch pFind and pReplacement
	VARIANT find_result;
	VariantInit(&find_result);

	call(DISPATCH_PROPERTYGET, &find_result, pSelection, L"Find", NULL, 0);
	pFind = find_result.pdispVal;

	// convert strings to wchar_t
	wchar_t *ws_find, *ws_replace;
	if ((ws_find = stringToWideString((char *)find.c_str())) == NULL)
		return false;
	if ((ws_replace = stringToWideString((char *)replace.c_str())) == NULL)
		return false;

	VARIANT find_variant, replace_variant;
	VariantInit(&find_variant);
	VariantInit(&replace_variant);
	find_variant.vt = VT_BSTR;
	find_variant.bstrVal = ws_find;
	replace_variant.vt = VT_BSTR;
	replace_variant.bstrVal = ws_replace;

	VARIANT replace_all_variant;
	VariantInit(&replace_all_variant);
	replace_all_variant.vt = VT_I4;
	replace_all_variant.lVal = wdReplaceAll;

	VARIANT execute_result;
	VariantInit(&execute_result);

	call(DISPATCH_METHOD, 
		&execute_result,
		pFind,
		L"Execute",
		NULL,
		11, 
		replace_all_variant,
		replace_variant,	
		optional_variant, optional_variant, optional_variant, optional_variant,
		optional_variant, optional_variant, optional_variant, optional_variant,
		find_variant);

	delete[] ws_find, ws_replace;

	return (!execute_result.boolVal) ? false : true;
}

void MSWord::quit()
{
	call(DISPATCH_METHOD, NULL, pApp, L"Quit", QuitID, 0);
}

bool MSWord::saveXmlFile(string &fname)
{
	return saveFile(fname, wdFormatXML);
}

bool MSWord::saveUnicodeFile(string &fname)
{
	return saveFile(fname, wdFormatUnicodeText);
}

bool MSWord::saveTextFile(string &fname)
{
	return saveFile(fname, wdFormatDOSText);
}

bool MSWord::saveFile(string &fname, int wdFormat)
{
	if (!is_success() || pDoc == NULL)
		return false;

	wchar_t *wfname;
	if ((wfname = stringToWideString((char *)fname.c_str())) == NULL)
		return false;

	VARIANT result, x, y;
	VariantInit(&result);
	VariantInit(&x);
	VariantInit(&y);
		
	// filename
	x.vt = VT_BSTR;
	x.bstrVal = wfname;
	
	// format
	y.vt = VT_I4;
	y.lVal = wdFormat;

	if (wdFormat == wdFormatUnicodeText)
	{
		VARIANT encoding;
		VariantInit(&encoding);
		encoding.vt = VT_I4;
		encoding.lVal = msoEncodingUTF8;
		call(DISPATCH_METHOD, &result, pDoc, L"SaveAs", NULL, 12,
			encoding,
			optional_variant,
			optional_variant,
			optional_variant,
			optional_variant,
			optional_variant,
			optional_variant,
			optional_variant,
			optional_variant,
			optional_variant,
			y,
			x);
	}
	else
	{
		if (wdFormat == wdFormatXML)
		{
			VARIANT falseVariant;
			VariantInit(&falseVariant);
			falseVariant.vt = VT_BOOL;
			falseVariant.boolVal = FALSE;

			call(
				DISPATCH_PROPERTYPUT,
				NULL,
				pDoc,
				L"XMLUseXSLTWhenSaving",
				NULL,
				1,
				falseVariant);
		}
		call(DISPATCH_METHOD, &result, pDoc, L"SaveAs", NULL, 2, y, x);
	}

	delete[] wfname;

	// result.boolVal is false even on success,
	// so return value is based on success_
	return (!is_success()) ? false : true;
}
