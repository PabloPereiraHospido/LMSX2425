#include <windows.h>
#include <string>
#include <stdexcept>
#include "olebase.h"
#include "msword.h"

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)
{
	bool notWord2003 = false;
	if (__argc < 3)
	{
		MessageBox(
			NULL,
			"Usage: doc2xml <source filename> <target filename>\r\n"
			"Return values:\r\n0\tSuccess\r\n"
			"1\tUnable to initialise Word\r\n"
			"2\tIncorrect version of Word\r\n"
			"3\tUnable to open document\r\n"
			"4\tUnable to save XML\r\n"
			"5\tSaved as Unicode text\r\n",
			"Doc2xml",
			MB_OK);
		return 6;
	}

	try {
		MSWord w;
		w.setVerbose(false);
		int version = w.getMajorVersion();

		if (version < 11)
		{
			notWord2003 = true;
			if (version < 9)
			  return 2;
		}

		string source, destination;
		source = *(++__argv);
		destination = *(++__argv);

		if (!w.openFile(source))
			return 3;

		if (notWord2003)
		{
			if (!w.saveUnicodeFile(destination))
				return 4;
			return 5;
		}
		else if (!w.saveXmlFile(destination))
			return 4;
		return 0;
	}
	catch (exception &e)
	{
		return 1;
	}
}

