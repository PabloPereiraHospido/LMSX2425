#include <windows.h>
#include <string>
#include <stdexcept>
#include "olebase.h"
#include "msword.h"

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)
{
	if (__argc < 3)
	{
		MessageBox(
			NULL,
			"Usage: xml2doc [-v] <source filename> <target filename>\r\n"
			"If flag -v (visible) is set, the Word instance remains open when the application closes.\r\n"
			"Return values:\r\n0\tSuccess\r\n"
			"1\tUnable to initialise Word\r\n"
			"2\tIncorrect version of Word\r\n"
			"3\tUnable to save document\r\n",
			"xml2doc",
			MB_OK);
		return 4;
	}

	try {
		MSWord w;
		w.setVerbose(false);

		int version = w.getMajorVersion();

		if (version < 11)
			return 2;

		string source, destination;

		bool visibleFlag = false;
		if (__argc == 4 && !strcmp("-v", *(++__argv)))
		  visibleFlag = true;

		source = *(++__argv);
		destination = *(++__argv);
		w.openFile(source);


		if (!w.saveFile(destination))
			return 3;
		if (visibleFlag)
		{
			w.visible(true);
			w.setQuitOnDestruct(false);
		}
		else
			w.close();
		return 0;
	}
	catch (exception &e)
	{
		return 1;
	}

}

