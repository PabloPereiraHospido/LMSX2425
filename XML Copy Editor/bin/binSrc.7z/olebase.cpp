// olebase.cpp

#include <windows.h>
#include <ole2.h>
#include <string>
#include "olebase.h"

OleBase::OleBase() : pApp(NULL), success(false), verbose(false), quit_on_destruct_(true)
{
	// define optional VARIANT
	optional_variant.vt = VT_ERROR;
	optional_variant.scode = DISP_E_PARAMNOTFOUND;
}

bool OleBase::fetchDISPID(LPOLESTR ptName, IDispatch *pDisp, DISPID *dispID)
{
	if (!is_success())
		return false;

	HRESULT hr;
	hr = pDisp->GetIDsOfNames(IID_NULL, &ptName, 1, LOCALE_USER_DEFAULT, dispID);
	if (FAILED(hr))
	{
		char *s;
		s = wideStringToString(ptName);
		error(string("GetIDsOfNames"), string(s));
		delete[] s;
		return false;
	}
	return true;
}

bool OleBase::getVerbose()
{
	return verbose;
}

bool OleBase::is_success()
{
	return success;
}

bool OleBase::visible(bool b)
{
	if (!is_success())
		return false;

	VARIANT x;
	x.vt = VT_I4;
	x.lVal = (b) ? TRUE : FALSE;

	return call(DISPATCH_PROPERTYPUT, NULL, pApp, L"Visible", NULL, 1, x);
}

bool OleBase::call(int autoType, VARIANT *pvResult, IDispatch *pDisp, LPOLESTR ptName, DISPID dispID, int cArgs...)
{
	if (!is_success())
		return false; 

	if (dispID == NULL && !fetchDISPID(ptName, pDisp, &dispID))
		return false;

	// begin variable-argument list
	va_list marker;
	va_start(marker, cArgs);

	// variables used...
	DISPPARAMS dp = { NULL, NULL, 0, 0 };
	DISPID dispidNamed = DISPID_PROPERTYPUT;

	// allocate memory for arguments...
	VARIANT *pArgs = new VARIANT[cArgs+1];
	
	// extract arguments
	for (int i = 0; i < cArgs; ++i)
		pArgs[i] = va_arg(marker, VARIANT);

	// build DISPPARAMS
	dp.cArgs = cArgs;
	dp.rgvarg = pArgs;

	// handle special case for DISPATCH_PROPERTYPUT 
	if (autoType & DISPATCH_PROPERTYPUT)
	{
		dp.cNamedArgs = 1;
		dp.rgdispidNamedArgs = &dispidNamed;
	}

	// make the call
	HRESULT hr;
	hr = pDisp->Invoke(dispID, IID_NULL, LOCALE_SYSTEM_DEFAULT, autoType, &dp, pvResult, NULL, NULL);
	
	if (FAILED(hr))
	{
		char *s = wideStringToString(ptName);
		error(string("Invoke"), string(s));
		delete[] s;
		return false;
	}
	
	// end variable-argument section
	va_end(marker);

	delete [] pArgs;

	return true;
}

void OleBase::error(const string &method, const string &argument)
{
	if (getVerbose())
	{
		string s;
		s = "An error has occurred in function: \"" + method + "\"\r\nUnable to resolve: \"" + argument + "\"";
		MessageBox(NULL, s.c_str(), "Automation client", MB_OK|MB_ICONINFORMATION|MB_SETFOREGROUND);
	}
	success = false;
}

wchar_t *OleBase::stringToWideString(char *s)
{
	if (!s)
		return NULL;

	wchar_t *ws;
	size_t len;
	len = strlen(s);

	ws = new wchar_t[len+1];
	if (!MultiByteToWideChar(CP_OEMCP, MB_PRECOMPOSED, s, len, ws, len+1))
		return NULL;
	*(ws+len) = '\0';
	return ws;
}

char *OleBase::wideStringToString(wchar_t *ws)
{
	if (!ws)
		return NULL;

	size_t len;
	char *s;

	len = wcslen(ws);
	s = new char[len+1];

	if (!WideCharToMultiByte(CP_ACP, 0, ws, -1, s, len+1, NULL, NULL))
		return NULL;
	*(s+len) = '\0';
	return s;
}

bool OleBase::getQuitOnDestruct()
{
	return quit_on_destruct_;
}

void OleBase::setQuitOnDestruct(bool b)
{
	quit_on_destruct_ = b;
}

void OleBase::setVerbose(bool b)
{
	verbose = b;
}
