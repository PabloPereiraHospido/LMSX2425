// wordcheck.cpp

#include <iostream>
#include <fstream>
#include <string>
#include "msword.h"

using namespace std;

int main(int argc, char *argv[])
{
	if (argc < 2)
	{
		cerr << "Usage: wordcheck <full path and filename> [<dictionary path>]" << endl;
		return 1;
	}

	string fname, dictionaryPath;
	fname = *(++argv);
	if (argc >= 3)
		dictionaryPath = *(++argv);

	ifstream ifs;
	ofstream correct, incorrect;
	ifs.open(fname.c_str());
	correct.open("correct.txt");
	incorrect.open("incorrect.txt");
	if (!ifs)
	{
		cerr << "Read error" << endl;
		return 1;
	}
	if (!correct || !incorrect)
	{
		cerr << "Write error" << endl;
		return 1;
	}

	MSWord wd;
	wd.visible(false);
	
	string line;
	while (getline(ifs, line, '\n'))
	{
		if (!wd.checkSpelling(line, dictionaryPath))
		{
			incorrect << line << endl;
		}
		else
			correct << line << endl;
		cout << ".";
	}
	cout << endl;

	return 0;
}
