// msie.cpp

#include <windows.h>
#include <string>
#include <ole2.h>
#include <stdexcept>
#include "msie.h"

MSIE::MSIE()
{
	CoInitialize(NULL);
	if ((success = application()) == false)
		throw runtime_error("MSIE::MSIE");
	fetchDISPID(L"Quit", pApp, &QuitID);
	fetchDISPID(L"HWND", pApp, &HandleID);
	fetchDISPID(L"MenuBar", pApp, &MenuBarID);
	fetchDISPID(L"Resizable", pApp, &ResizableID);
	fetchDISPID(L"StatusBar", pApp, &StatusBarID);
	fetchDISPID(L"TheaterMode", pApp, &TheaterModeID);
	fetchDISPID(L"ToolBar", pApp, &ToolBarID);
}

MSIE::~MSIE()
{
	if (getQuitOnDestruct())
		quit();
	CoUninitialize();
}

bool MSIE::application()
{
	CoInitialize(NULL);
	CLSID clsid;
	HRESULT hr = CLSIDFromProgID(L"internetexplorer.application", &clsid);

	if (FAILED(hr))
	{
		OleBase::error(string("CLSIDFromProgID"), string("ie.app"));
		success = false;
		return false;
	}

	// fetch IDispatch
	hr = CoCreateInstance(clsid, NULL, CLSCTX_LOCAL_SERVER, IID_IDispatch, (void **)&pApp);
	if (FAILED(hr))
	{
		error(string("CoCreateInstance"), string("IDispatch"));
		success = false;
		return false;
	}
	
	return true;
}

bool MSIE::menubar(bool b)
{
	if (!is_success())
		return false;

	VARIANT x;
	x.vt = VT_I4;
	x.lVal = (b) ? TRUE : FALSE;

	return call(DISPATCH_PROPERTYPUT, NULL, pApp, L"MenuBar", MenuBarID, 1, x);
}

bool MSIE::resizable(bool b)
{
	if (!is_success())
		return false;

	VARIANT x;
	x.vt = VT_I4;
	x.lVal = (b) ? TRUE : FALSE;

	return call(DISPATCH_PROPERTYPUT, NULL, pApp, L"Resizable", ResizableID, 1, x);
}

bool MSIE::statusbar(bool b)
{
	if (!is_success())
		return false;

	VARIANT x;
	x.vt = VT_I4;
	x.lVal = (b) ? TRUE : FALSE;

	return call(DISPATCH_PROPERTYPUT, NULL, pApp, L"StatusBar", StatusBarID, 1, x);
}

bool MSIE::theatermode(bool b)
{
	if (!is_success())
		return false;

	VARIANT x;
	x.vt = VT_I4;
	x.lVal = (b) ? TRUE : FALSE;

	return call(DISPATCH_PROPERTYPUT, NULL, pApp, L"TheaterMode", TheaterModeID, 1, x);
}

bool MSIE::toolbar(bool b)
{
	if (!is_success())
		return false;

	VARIANT x;
	x.vt = VT_I4;
	x.lVal = (b) ? TRUE : FALSE;

	return call(DISPATCH_PROPERTYPUT, NULL, pApp, L"ToolBar", ToolBarID, 1, x);
}

bool MSIE::navigate(string &url)
{
	if (!is_success() || url == "")
		return false;

	wchar_t *wurl;
	if ((wurl = stringToWideString((char *)url.c_str())) == NULL)
		return false;

	VARIANT result;
	VariantInit(&result);
	VARIANT x;
	x.vt = VT_BSTR;
	x.bstrVal = wurl;
		
	call(DISPATCH_METHOD, &result, pApp, L"Navigate", NULL, 1, x);
	delete[] wurl;
	return true;
}

void MSIE::quit()
{
	call(DISPATCH_METHOD, NULL, pApp, L"Quit", QuitID, 0);
}

HWND MSIE::ie_handle()
{
	if (!is_success())
		return NULL;

	HWND hwnd;
	VARIANT result;
	VariantInit(&result);
	call(DISPATCH_PROPERTYGET, &result, pApp, L"HWND", HandleID, 0);
	hwnd = (HWND)result.pdispVal;

	return hwnd;
}
